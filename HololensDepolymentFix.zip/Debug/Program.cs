﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Tools.Deploy;
using System.Net;

namespace HoloLensDeploymentFix
{
    class Program
    {
        static void Main(string[] args)
        {
            RemoteDeployClient client = RemoteDeployClient.CreateRemoteDeployClient();
            client.Connect(new ConnectionOptions()
            {
                Credentials = new NetworkCredential("DevToolsUser", string.Empty),
                IPAddress = IPAddress.Parse(args[0])
            });
            client.RemoteDevice.DeleteFile(@"C:\Data\Users\DefaultAccount\AppData\Local\DevelopmentFiles\VSRemoteTools\x86\CoreCLR\mscorlib.ni.dll");
        }
    }
}
